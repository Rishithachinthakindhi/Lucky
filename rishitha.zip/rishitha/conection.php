<?php
$mysqli=mysqli_connect('localhost','root','','lucky');
if($mysqli===false){
    die("ERROR;could not connect."
    .mysqli_connect_error());
}
$name = $_REQUEST['name'];
$phone_no =$_REQUEST['phone_no'];
$email = $_REQUEST['email'];
$address =$_REQUEST['address'];

$sql = "INSERT INTO FORM VALUES('$name','$phone_no','$email','$address')";
if(mysqli_query($mysqli,$sql)){
    echo"<h3> data stored in a database."
         
}
else{

}
$mysqli->close();
?>
